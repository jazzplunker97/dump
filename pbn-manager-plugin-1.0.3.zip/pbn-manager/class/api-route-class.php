<?php

class Route {
    /**
     * Initilize route
     *
     * @return void
     */
    public function initialize()
    {
        add_action( 'rest_api_init', array( $this, 'register' ) );
    }

    /**
     * Register hooks
     *
     * @return void
     */
    public function register() 
    {
        (new \PluginRoute)->initialize();
        (new \ThemeRoute)->initialize();
        (new \PostRoute)->initialize();
        (new \UserRoute)->initialize();
        (new \OptionRoute)->initialize();
        (new \WidgetRoute)->initialize();
        (new \TaxonomyRoute)->initialize();
	}
}