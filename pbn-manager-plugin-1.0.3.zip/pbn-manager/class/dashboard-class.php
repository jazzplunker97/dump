<?php

class Dashboard
{
    /**
     * Initilize dashboard
     *
     * @return void
     */
    public function initialize()
    {
        add_action('admin_menu', array( $this, 'add_dashboard_menu' ) );
    }

    public function add_dashboard_menu()
    {
        add_menu_page(
            'PBN DJ Manager',
            'PBN DJ Manager',
            'manage_options',
            'pbn-manager',
            'render_dashboard_page',
            'dashicons-admin-generic',
            30
        );
    }
}