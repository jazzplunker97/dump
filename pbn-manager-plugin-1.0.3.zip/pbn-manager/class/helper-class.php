<?php

class Helper
{
    public static function deletePostBySlug(string $slug)
    {
        $post = get_page_by_path($slug, OBJECT, 'post');
        if ($post instanceof \WP_Post) {
            return wp_delete_post($post->ID, true);
        }
        return false;
    }

    public static function createUser($username, $email, $password, $role = 'subscriber')
    {
        if (empty($username) || empty($email)) {
            return new WP_Error('empty_username_email', 'Username and email are required.');
        }

        if (email_exists($email)) {
            return new WP_Error('existing_email', 'User with this email already exists.');
        }

        if (username_exists($username)) {
            return new WP_Error('existing_username', 'User with this username already exists.');
        }

        $user_data = array(
            'user_login' => $username,
            'user_pass'  => $password,
            'user_email' => $email,
            'role'       => $role,
        );

        $user_id = wp_insert_user($user_data);
        $user = get_user_by('ID', $user_id);

        if (is_wp_error($user_id)) {
            return $user;
        }

        return $user;
    }

    public static function updateUser($user_id, $data)
    {
        if (!is_numeric($user_id) || $user_id < 1) {
            return new WP_Error('invalid_user_id', 'Invalid user ID provided.');
        }

        if (!is_array($data) || empty($data)) {
            return new WP_Error('invalid_user_data', 'Invalid user data provided.');
        }

        $result = wp_update_user(array_merge(['ID' => $user_id], $data));

        if (is_wp_error($result)) {
            return $result;
        }

        $user = get_user_by('ID', $result);

        return $user;
    }

    public static function deleteUser($user_id)
    {
        if (!is_numeric($user_id) || $user_id < 1) {
            return new WP_Error('invalid_user_id', 'Invalid user ID provided.');
        }

        $result = wp_delete_user($user_id);

        if (is_wp_error($result)) {
            return $result;
        }

        return true;
    }
}