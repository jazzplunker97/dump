<?php

class Middleware extends \WP_REST_Request 
{
    /**
     * Token Authorization
     *
     * @var string
     */
    protected string $token = '';

    /**
     * Construct
     */
    public function __construct()
    {
        $this->token = get_option('pbn_manager_token', '');
    }

    /**
     * Authenticate middleware
     *
     * @param object $request
     * @return boolean
     */
    public function authenticate(object $request): bool
    {
        $token = $request->get_header('authorization');

        if (is_valid_token($token)) {
            return true;
        }
        
        return false;
    }

    /**
     * Undocumented function
     *
     * @param string $status
     * @param string $message
     * @param array $data
     * @return string|false
     */
    protected function response(string $status, string $message, array $data = [])
    {
        echo wp_json_encode([
            'status'  => $status,
            'message' => $message,
            'data' => $data
        ]);
    }
}