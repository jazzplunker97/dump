<?php

class Option
{
    public $widgets;

    public function __construct()
    {
        $options = get_option('pbn_manager', null);

        if (!$options) {
            update_option( 'pbn_manager', [] );
        }

        $this->widgets = $options['widgets'];
    }

    public function save()
    {
        $options = get_option('pbn_manager', []);
        $options['widgets'] = $this->widgets;
        update_option( 'pbn_manager', $options );
        return $options;
    }
}