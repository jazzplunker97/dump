<?php

class OptionRoute extends Middleware
{
    use OptionTrait;

    /**
     * Initilize route
     *
     * @return void
     */
    public function initialize()
    {
        register_rest_route( 'pbn/v1', 'option', array(
            'methods'  => \WP_REST_Server::READABLE,
            'callback' => array( $this, 'get_option' ),
            'permission_callback' => array( $this, 'authenticate' )
        ));
        register_rest_route( 'pbn/v1', 'option', array(
            'methods'  => \WP_REST_Server::CREATABLE,
            'callback' => array( $this, 'update_option' ),
            'permission_callback' => array( $this, 'authenticate' )
        ));
    }

    public function get_option(\WP_REST_Request $request)
    {
        try {
            return $this->response('success', 'operation successfully', $this->get_data());
        } catch (\Throwable $th) {
            return $this->response('error', $th->getMessage());
        }
    }

    public function update_option(\WP_REST_Request $request)
    {
        $body = $request->get_json_params();

        try {
            $results = $this->update_data($body);
            return $this->response('success', 'operation successfully', $results);
        } catch (\Throwable $th) {
            return $this->response('error', $th->getMessage());
        }
    }
}