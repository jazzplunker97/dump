<?php

class PluginRoute extends Middleware
{
    /**
     * Plugin Service
     *
     * @var Plugin_Service
     */
    public Plugin_Service $service;
    
    /**
     * Construct
     */
    public function __construct()
    {
        parent::__construct();
        $this->service = new Plugin_Service;
    }

    /**
     * Initilize route
     *
     * @return void
     */
    public function initialize()
    {
        register_rest_route( 'pbn/v1', 'plugin', array(
            'methods'  => \WP_REST_Server::READABLE,
            'callback' => array( $this, 'get_plugin' ),
            'permission_callback' => array( $this, 'authenticate' )
        ));
        register_rest_route( 'pbn/v1', 'plugin/install', array(
            'methods'  => \WP_REST_Server::CREATABLE,
            'callback' => array( $this, 'install_plugin' ),
            'permission_callback' => array( $this, 'authenticate' )
        ));
        register_rest_route( 'pbn/v1', 'plugin/activate', array(
            'methods'  => \WP_REST_Server::CREATABLE,
            'callback' => array( $this, 'activate_plugin' ),
            'permission_callback' => array( $this, 'authenticate' )
        ));
        register_rest_route( 'pbn/v1', 'plugin/install-activate', array(
            'methods'  => \WP_REST_Server::CREATABLE,
            'callback' => array( $this, 'install_activate_plugin' ),
            'permission_callback' => array( $this, 'authenticate' )
        ));
        register_rest_route( 'pbn/v1', 'plugin/deactivate', array(
            'methods'  => \WP_REST_Server::CREATABLE,
            'callback' => array( $this, 'deactivate_plugin' ),
            'permission_callback' => array( $this, 'authenticate' )
        ));
        register_rest_route( 'pbn/v1', 'plugin/delete', array(
            'methods'  => \WP_REST_Server::CREATABLE,
            'callback' => array( $this, 'delete_plugin' ),
            'permission_callback' => array( $this, 'authenticate' )
        ));
        register_rest_route( 'pbn/v1', 'plugin/deactivate-delete', array(
            'methods'  => \WP_REST_Server::CREATABLE,
            'callback' => array( $this, 'deactivate_delete_plugin' ),
            'permission_callback' => array( $this, 'authenticate' )
        ));
        register_rest_route( 'pbn/v1', 'plugin/update-all', array(
            'methods'  => \WP_REST_Server::CREATABLE,
            'callback' => array( $this, 'update_all_plugin' ),
            'permission_callback' => array( $this, 'authenticate' )
        ));
        register_rest_route( 'pbn/v1', 'plugin/check-update', array(
            'methods'  => \WP_REST_Server::CREATABLE,
            'callback' => array( $this, 'check_update' ),
            'permission_callback' => array( $this, 'authenticate' )
        ));
    }

    public function get_plugin(\WP_REST_Request $request)
    {
        $plugins = get_plugins();
        echo wp_json_encode($plugins);
    }

    /**
     * Install new plugin
     *
     * @return void
     */
    public function install_plugin(\WP_REST_Request $request)
    {
        $body = $request->get_json_params();

        $skin     = new \WP_Ajax_Upgrader_Skin();
        $upgrader = new \Plugin_Upgrader( $skin );

        try {
            $inc = 0;
            $result = [];
            foreach ($body['plugins'] as $plugin) {
                $api = plugins_api( 'plugin_information',
                    array(
                        'slug' => $plugin['slug'],
                        'fields' => array(),
                    )
                );
                $result[$plugin['slug']] = $upgrader->install($plugin['download_link']);
                $inc++;
            }
            return $this->response('success', "success install {$inc} plugins", $result);
        } catch (\Throwable $th) {
            return $this->response('error', $th->getMessage());
        }
    }

    /**
     * Activate plugin
     * 
     * @param \WP_REST_Request $request
     * @return void
     */
    public function activate_plugin(\WP_REST_Request $request)
    {
        $body = $request->get_json_params();

        try {
            $inc = 0;
            $result = [];
            foreach ($body['plugins'] as $plugin) {
                $result[$plugin['slug']] = $this->service->activatePluginBySlug($plugin['slug']);
                $inc++;
            }
            return $this->response('success', "success activate {$inc} plugins", $result);
        } catch (\Throwable $th) {
            return $this->response('error', $th->getMessage());
        }
    }

    /**
     * Install & activate plugin
     * 
     * @param \WP_REST_Request $request
     * @return void
     */
    public function install_activate_plugin(\WP_REST_Request $request)
    {
        $body = $request->get_json_params();

        $skin     = new \WP_Ajax_Upgrader_Skin();
        $upgrader = new \Plugin_Upgrader( $skin );

        try {
            $inc = 0;
            $result = [];
            foreach ($body['plugins'] as $plugin) {
                $api = plugins_api( 'plugin_information',
                    array(
                        'slug' => $plugin['slug'],
                        'fields' => array(),
                    )
                );
                $result[$plugin['slug']] = $upgrader->install($plugin['download_link']);
                $this->service->activatePluginBySlug($plugin['slug']);
                $inc++;
            }
            return $this->response('success', "success install & activate {$inc} plugins", $result);
        } catch (\Throwable $th) {
            return $this->response('error', $th->getMessage());
        }
    }

    /**
     * Deactivate plugin
     *
     * @param \WP_REST_Request $request
     * @return void
     */
    public function deactivate_plugin(\WP_REST_Request $request)
    {
        $body = $request->get_json_params();

        try {
            $inc = 0;
            $result = [];
            foreach ($body['plugins'] as $plugin) {
                $result[$plugin['slug']] = $this->service->deactivatePluginBySlug($plugin['slug']);
                $inc++;
            }
            return $this->response('success', "success deactivate {$inc} plugins", $result);
        } catch (\Throwable $th) {
            return $this->response('error', $th->getMessage());
        }
    }

    /**
     * Delete plugin
     *
     * @param \WP_REST_Request $request
     * @return void
     */
    public function delete_plugin(\WP_REST_Request $request)
    {
        $body = $request->get_json_params();

        try {
            $inc = 0;
            $result = [];
            foreach ($body['plugins'] as $plugin) {
                $result[$plugin['slug']] = $this->service->deletePluginBySlug($plugin['slug']);
                $inc++;
            }
            return $this->response('success', "success delete {$inc} plugins", $result);
        } catch (\Throwable $th) {
            return $this->response('error', $th->getMessage());
        }
    }

    public function update_all_plugin()
    {
        $skin     = new \WP_Ajax_Upgrader_Skin();
        $upgrader = new Plugin_Upgrader( $skin );

        $plugins = get_plugins();
        $update_results = array();
        $inc = 0;

        try {
            foreach ($plugins as $plugin_path => $plugin_info) {
                $needReactivate = false;
                if (is_plugin_active($plugin_path)) {
                    $needReactivate = true;
                }

                $update_result = $upgrader->upgrade($plugin_path);
    
                if (is_wp_error($update_result)) {
                    $update_results[$plugin_path] = $update_result;
                } else {
                    $inc++;
                    $update_results[$plugin_path] = true;
                }

                if ($needReactivate) {
                    activate_plugin($plugin_path);
                }
            }

            return $this->response('success', "success update {$inc} plugins", $update_results);
        } catch (\Throwable $th) {
            return $this->response('error', $th->getMessage());
        }
    }

    /**
     * Deactivate & delete plugin
     *
     * @param \WP_REST_Request $request
     * @return void
     */
    public function deactivate_delete_plugin(\WP_REST_Request $request)
    {
        $body = $request->get_json_params();

        try {
            $inc = 0;
            $result = [];
            foreach ($body['plugins'] as $plugin) {
                $this->service->deactivatePluginBySlug($plugin['slug']);
                $result[$plugin['slug']] = $this->service->deletePluginBySlug($plugin['slug']);
                $inc++;
            }
            return $this->response('success', "success deactivate & delete {$inc} plugins", $result);
        } catch (\Throwable $th) {
            return $this->response('error', $th->getMessage());
        }
    }

    public function check_update()
    {
        try {
            $this->service->force_check_update();
            return $this->response('success', "success force check update", []);
        } catch (\Throwable $th) {
            return $this->response('error', $th->getMessage());
        }
    }    
}