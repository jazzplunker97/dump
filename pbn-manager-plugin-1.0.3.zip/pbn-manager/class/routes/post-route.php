<?php

class PostRoute extends Middleware
{
    /**
     * Initilize route
     *
     * @return void
     */
    public function initialize()
    {
        register_rest_route( 'pbn/v1', 'post', array( 
            array(
                'methods'  => \WP_REST_Server::READABLE,
                'callback' => array( $this, 'get_post' ),
                'permission_callback' => array( $this, 'authenticate' )
            ), 
            array(
                'methods'  => \WP_REST_Server::CREATABLE,
                'callback' => array( $this, 'store_post' ),
                'permission_callback' => array( $this, 'authenticate' )
            ),
        ));

        register_rest_route( 'pbn/v1', 'post/delete', array( 
            'methods'  => \WP_REST_Server::CREATABLE,
            'callback' => array( $this, 'delete_post' ),
            'permission_callback' => array( $this, 'authenticate' )
        ));
    }

    /**
     * Get list post
     *
     * @return void
     */
    public function get_post()
    {
        $data = get_posts();
        echo wp_json_encode($data);
    }

    /**
     * Store new post
     *
     * @return void
     */
    public function store_post(\WP_REST_Request $request)
    {
        $body = $request->get_json_params();

        try {
            $result = count($this->createMultiplePost($body['posts']));
        } catch (\Throwable $th) {
            return $this->response('error', $th->getMessage());
        }

        return $this->response('success', "Insert $result new post success", $body);
    }

    /**
     * Delete posts
     *
     * @return void
     */
    public function delete_post(\WP_REST_Request $request)
    {
        $body = $request->get_json_params();

        $inc = 0;

        try {
            foreach ($body['posts'] as $slug) {
                if (Helper::deletePostBySlug($slug)) {
                    $inc++;
                }
            }
        } catch (\Throwable $th) {
            return $this->response('error', $th->getMessage());
        }

        return $this->response('success', "Delete {$inc} post success", $body);
    }

    private function createMultiplePost($postsData)
    {
        $result = [];

        foreach ($postsData as $postData) {
            $post = array(
                'post_title'    => wp_strip_all_tags( $postData['title'] ),
                'post_content'  => $postData['content'],
                'post_status'   => $postData['post_status'],
                'post_author'   => 1,
            );

            if ($postData['meta_slug']) {
                $post['post_name'] = $postData['meta_slug'];
            }

            $postId = wp_insert_post( $post );

            foreach (array_values($postData['categories']) as $key => $category) {
                if (!$categoryId = term_exists($category, 'category')) {
                    $categoryId = wp_create_category($category);
                }
                wp_set_post_terms($postId, $categoryId, 'category', $key != 0);
            }

            foreach ($postData['tags'] as $tag) {
                if (!$tagId = term_exists($tag, 'post_tag')) {
                    $tagId = wp_create_tag($tag);
                }
                wp_set_post_terms($postId, $tag, 'post_tag', true);
            }

            if ($imageUrl = $postData['featured_image']) {
                $upload = wp_upload_bits(basename($imageUrl), null, file_get_contents($imageUrl));
                if (!$upload['error']) {
                    $attachment = array(
                        'post_mime_type' => $upload['type'],
                        'post_title'     => sanitize_file_name(pathinfo($upload['file'], PATHINFO_FILENAME)),
                        'post_content'   => '',
                        'post_status'    => 'inherit',
                    );
                    $attachmentId = wp_insert_attachment($attachment, $upload['file'], $postId);
                    if (!is_wp_error($attachmentId)) {
                        $attachmentData = wp_generate_attachment_metadata($attachmentId, $upload['file']);
                        wp_update_attachment_metadata($attachmentId, $attachmentData);
                    }
                    set_post_thumbnail($postId, $attachmentId);
                }
            }

            if ($postData['meta_focus_keyphrase']) {
                update_post_meta($postId, '_yoast_wpseo_focuskw', $postData['meta_focus_keyphrase']);
            }
            if ($postData['meta_description']) {
                update_post_meta($postId, '_yoast_wpseo_metadesc', $postData['meta_description']);
            }
            if ($postData['meta_slug']) {
                update_post_meta($postId, '_wp_desired_post_slug', $postData['meta_slug']);
            }

            $result[] = $postId;
        }

        return $result;
    }
}