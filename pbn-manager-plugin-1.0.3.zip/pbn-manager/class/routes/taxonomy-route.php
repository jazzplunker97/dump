<?php

class TaxonomyRoute extends Middleware
{
    /**
     * Taxonomy Service
     *
     * @var Taxonomy_Service
     */
    public Taxonomy_Service $service;

    /**
     * Construct
     */
    public function __construct()
    {
        parent::__construct();
        $this->service = new Taxonomy_Service;
    }

    /**
     * Initilize route
     *
     * @return void
     */
    public function initialize()
    {
        register_rest_route( 'pbn/v1', 'taxonomy', array(
            array(
                'methods'  => \WP_REST_Server::READABLE,
                'callback' => array( $this, 'get_taxonomy' ),
                'permission_callback' => array( $this, 'authenticate' )
            ),
        ));
    }

    public function get_taxonomy()
    {
        return $this->response('success', 'operation successfully', [
            'cateories' => $this->service->get_categories(),
            'tags' => $this->service->get_tags()
        ]);
    }
}