<?php

class ThemeRoute extends Middleware
{
    /**
     * Initilize route
     *
     * @return void
     */
    public function initialize()
    {
        register_rest_route( 'pbn/v1', 'theme', array(
            'methods'  => \WP_REST_Server::READABLE,
            'callback' => array( $this, 'get_theme' ),
            'permission_callback' => array( $this, 'authenticate' )
        ));
        register_rest_route( 'pbn/v1', 'theme/install', array(
            'methods'  => \WP_REST_Server::CREATABLE,
            'callback' => array( $this, 'install_theme' ),
            'permission_callback' => array( $this, 'authenticate' )
        ));
        register_rest_route( 'pbn/v1', 'theme/activate', array(
            'methods'  => \WP_REST_Server::CREATABLE,
            'callback' => array( $this, 'activate_theme' ),
            'permission_callback' => array( $this, 'authenticate' )
        ));
        register_rest_route( 'pbn/v1', 'theme/install-activate', array(
            'methods'  => \WP_REST_Server::CREATABLE,
            'callback' => array( $this, 'install_activate_theme' ),
            'permission_callback' => array( $this, 'authenticate' )
        ));
        register_rest_route( 'pbn/v1', 'theme/delete', array(
            'methods'  => \WP_REST_Server::CREATABLE,
            'callback' => array( $this, 'delete_theme' ),
            'permission_callback' => array( $this, 'authenticate' )
        ));
        register_rest_route( 'pbn/v1', 'theme/update-all', array(
            'methods'  => \WP_REST_Server::CREATABLE,
            'callback' => array( $this, 'update_theme' ),
            'permission_callback' => array( $this, 'authenticate' )
        ));
    }

    public function get_theme(\WP_REST_Request $request)
    {
        $themes = get_themes();
        echo wp_json_encode($themes);
    }

    /**
     * Install new theme
     *
     * @return void
     */
    public function install_theme(\WP_REST_Request $request)
    {
        $body = $request->get_json_params();

        $skin     = new \WP_Ajax_Upgrader_Skin();
        $upgrader = new \Theme_Upgrader( $skin );

        try {
            $inc = 0;
            $result = [];
            foreach ($body['themes'] as $theme) {
                if (!$theme['custom'] && !$theme['download_link']) {
                    $api = themes_api('theme_information', array(
                        'slug' => $theme['slug'],
                        'fields' => array(),
                    ));
                    $result[$theme['slug']] = $upgrader->install($api->download_link);
                } else {
                    $result[$theme['slug']] = $upgrader->install($theme['download_link']);
                }
                $inc++;
            }
            return $this->response('success', "success install {$inc} themes", $result);
        } catch (\Throwable $th) {
            return $this->response('error', $th->getMessage());
        }
    }

    /**
     * Activate new theme
     *
     * @return void
     */
    public function activate_theme(\WP_REST_Request $request)
    {
        $body = $request->get_json_params();
        $slug = $body['theme']['slug'];
        $result = [];

        try {
            $theme = wp_get_theme($slug);
            if (!$theme->exists()) {
                return $this->response('error', "Theme with slug '{$slug}' not found");
            }

            $result[$theme['slug']] = switch_theme($theme->get_stylesheet());

            return $this->response('success', "Theme '{$theme->get('Name')}' activated successfully", $result);
        } catch (\Throwable $th) {
            return $this->response('error', $th->getMessage());
        }
    }

    /**
     * Activate & install theme
     *
     * @return void
     */
    public function install_activate_theme(\WP_REST_Request $request)
    {
        $body = $request->get_json_params();
        $themes = $body['themes'];
        $activeThemeSlug = $body['active'];

        $skin     = new \WP_Ajax_Upgrader_Skin();
        $upgrader = new \Theme_Upgrader( $skin );

        try {
            $inc = 0;
            $result = ['install' => [], 'activate' => null];
            foreach ($themes as $theme) {

                if (!$theme['custom'] && !$theme['download_link']) {
                    $api = themes_api('theme_information', array(
                        'slug' => $theme['slug'],
                        'fields' => array(),
                    ));
                    $result['install'][$theme['slug']] = $upgrader->install($api->download_link);
                } else {
                    $result['install'][$theme['slug']] = $upgrader->install($theme['download_link']);
                }
                $inc++;
            }

            $theme = wp_get_theme($activeThemeSlug);
            if (!$theme->exists()) {
                return $this->response('error', "Theme with slug '{$activeThemeSlug}' not found");
            }
            $result['activate'] = switch_theme($theme->get_stylesheet());

            return $this->response('success', "success install {$inc} themes and activete {$theme->get('Name')} theme", $result);
        } catch (\Throwable $th) {
            return $this->response('error', $th->getMessage());
        }
    }

    /**
     * Delete theme
     *
     * @return void
     */
    public function delete_theme(\WP_REST_Request $request)
    {
        $body = $request->get_json_params();

        try {
            $inc = 0;
            $result = [];
            foreach ($body['themes'] as $theme) {
                $theme = wp_get_theme($theme['slug']);

                if (!$theme->exists()) {
                    $result[$theme['slug']] = $this->response('error', "Theme with slug '{$theme['slug']}' not found");
                    continue;
                }

                $deleteResult = delete_theme($theme->get_stylesheet());
                if (is_wp_error($deleteResult)) {
                    $result[$theme['slug']] = $this->response('error', $deleteResult->get_error_message());
                    continue;
                }

                $result[$theme['slug']] = $deleteResult;

                $inc++;
            }
            return $this->response('success', "success delete {$inc} themes", $result);
        } catch (\Throwable $th) {
            return $this->response('error', $th->getMessage());
        }
    }

    /**
     * Update theme
     *
     * @return void
     */
    public function update_theme(\WP_REST_Request $request)
    {
        $body = $request->get_json_params();

        $skin     = new \WP_Ajax_Upgrader_Skin();
        $upgrader = new Theme_Upgrader($skin);
        $themes = wp_get_themes();
        $update_results = array();

        try {
            $inc = 0;
            foreach ($themes as $theme_slug => $theme_info) {
                $update_result = $upgrader->upgrade($theme_slug);
                if (is_wp_error($update_result)) {
                    $update_results[$theme_slug] = $update_result;
                } else {
                    $inc++;
                    $update_results[$theme_slug] = true;
                }
            }

            return $this->response('success', "success update {$inc} themes", $update_results);
        } catch (\Throwable $th) {
            return $this->response('error', $th->getMessage());
        }
    }
}