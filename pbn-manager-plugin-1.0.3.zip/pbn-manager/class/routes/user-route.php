<?php

class UserRoute extends Middleware
{
    /**
     * Initilize route
     *
     * @return void
     */
    public function initialize()
    {
        register_rest_route( 'pbn/v1', 'user', array(
            array(
                'methods'  => \WP_REST_Server::READABLE,
                'callback' => array( $this, 'get_user' ),
                'permission_callback' => array( $this, 'authenticate' )
            ),
            array(
                'methods'  => \WP_REST_Server::CREATABLE,
                'callback' => array( $this, 'create_user' ),
                'permission_callback' => array( $this, 'authenticate' )
            ),
        ));

        register_rest_route( 'pbn/v1', 'user/update', array(
            'methods'  => \WP_REST_Server::CREATABLE,
            'callback' => array( $this, 'update_user' ),
            'permission_callback' => array( $this, 'authenticate' )
        ));

        register_rest_route( 'pbn/v1', 'user/delete', array(
            'methods'  => \WP_REST_Server::CREATABLE,
            'callback' => array( $this, 'delete_user' ),
            'permission_callback' => array( $this, 'authenticate' )
        ));
    }

    public function get_user(\WP_REST_Request $request)
    {
        try {
            $users = get_users();
            $roles = get_editable_roles();

            return $this->response('success', 'operation successfully', ['users' => $users, 'roles' => $roles]);
        } catch (\Throwable $th) {
            return $this->response('error', $th->getMessage());
        }
    }

    public function create_user(\WP_REST_Request $request)
    {
        $body = $request->get_json_params();

        try {
            $user = Helper::createUser($body['username'], $body['email'], $body['password'], $body['role']);

            return $this->response('success', 'operation successfully', ['user' => $user]);
        } catch (\Throwable $th) {
            return $this->response('error', $th->getMessage());
        }
    }

    public function update_user(\WP_REST_Request $request)
    {
        $body = $request->get_json_params();

        try {
            $user = Helper::updateUser($body['user_id'], [
                'user_email' => $body['user_email'],
                'user_pass' => $body['user_pass'],
                'user_url' => $body['user_url'],
                'role' => $body['role'],
            ]);

            return $this->response('success', 'operation successfully', ['user' => $user]);
        } catch (\Throwable $th) {
            return $this->response('error', $th->getMessage(), $body);
        }
    }

    public function delete_user(\WP_REST_Request $request)
    {
        $body = $request->get_json_params();

        try {
            $user = Helper::deleteUser($body['user_id']);

            return $this->response('success', 'operation successfully', ['result' => $user]);
        } catch (\Throwable $th) {
            return $this->response('error', $th->getMessage(), $body);
        }
    }
}