<?php

class WidgetRoute extends Middleware
{
    /**
     * Widget Service
     *
     * @var Widget_Service
     */
    public Widget_Service $service;
    
    /**
     * Construct
     */
    public function __construct()
    {
        parent::__construct();
        $this->service = new Widget_Service;
    }

    /**
     * Initilize route
     *
     * @return void
     */
    public function initialize()
    {
        register_rest_route( 'pbn/v1', 'widget', array(
            array(
                'methods'  => \WP_REST_Server::READABLE,
                'callback' => array( $this, 'get_widget' ),
                'permission_callback' => array( $this, 'authenticate' )
            ),
            array(
                'methods'  => \WP_REST_Server::CREATABLE,
                'callback' => array( $this, 'update_widget' ),
                'permission_callback' => array( $this, 'authenticate' )
            ),
        ));
    }

    /**
     * Get widget route
     *
     * @return void
     */
    public function get_widget()
    {
        $active_widgets = $this->service->get_widgets();

        return $this->response('success', 'operation successfully', $active_widgets);
    }

    /**
     * Update widget route
     *
     * @param \WP_REST_Request $request
     * @return void
     */
    public function update_widget(\WP_REST_Request $request)
    {
        $body = $request->get_json_params();

        try {
            $option = new Option;
            $option->widgets = $body['widgets'];
            $options = $option->save();

            $response = $this->service->update($options['widgets']);

            return $this->response('success', 'operation successfully', $response);
        } catch (\Throwable $th) {
            return $this->response('error', $th->getMessage(), (array) $th);
        }
    }
}