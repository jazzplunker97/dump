<?php

class Plugin_Service
{
    /**
     * Force check plugin
     *
     * @return void
     */
    public function force_check_update()
    {
        add_action('admin_init', [$this, 'check_plugin_hook']);
    }

    /**
     * Force check plugin hook
     *
     * @return void
     */
    public function check_plugin_hook() {
        delete_site_transient('update_plugins');
        wp_update_plugins();
    }

    /**
     * Activate plugin by slug
     *
     * @param string $slug
     * @return void
     */
    public function activatePluginBySlug(string $slug) {
        $plugins = get_plugins();
        foreach ($plugins as $plugin_file => $plugin_info) {
            if (strpos($plugin_file, $slug) !== false) {
                return activate_plugin($plugin_file);
            }
        }
        return new \WP_Error('plugin_not_found', 'Plugin not found.');
    }

    /**
     * Deactivate plugin by slug
     *
     * @param string $slug
     * @return void
     */
    public function deactivatePluginBySlug(string $slug) {
        $active_plugins = get_option('active_plugins', array());
        foreach ($active_plugins as $key => $plugin_file) {
            if (strpos($plugin_file, $slug) !== false) {
                unset($active_plugins[$key]);
                update_option('active_plugins', $active_plugins);
                wp_cache_delete('plugins', 'plugins');
                do_action('deactivate_' . $plugin_file);
                return null;
            }
        }
        return new \WP_Error('plugin_not_found', 'Plugin not found or not activated.');
    }

    /**
     * Deactivate and delete a plugin by slug
     *
     * @param string $slug Plugin slug.
     *
     * @return mixed|\WP_Error|null
     */
    public function deletePluginBySlug(string $slug) 
    {
        $plugin_dir = WP_PLUGIN_DIR . '/' . $slug;
        if (file_exists($plugin_dir) && is_dir($plugin_dir)) {
            $delete_result = $this->deleteDirectory($plugin_dir, true);
            // return $plugin_dir;
            if (!$delete_result) {
                return new \WP_Error('delete_failed', 'Error deleting the plugin directory.');
            }
        }
        return null;
    }

    /**
     * Recursively delete a directory and its contents
     *
     * @param string $dir Directory path.
     *
     * @return bool
     */
    public function deleteDirectory($dir) {
        if (!is_dir($dir)) {
            return false;
        }

        $files = array_diff(scandir($dir), array('.', '..'));

        foreach ($files as $file) {
            (is_dir("$dir/$file")) ? $this->deleteDirectory("$dir/$file") : unlink("$dir/$file");
        }

        return rmdir($dir);
    }
}