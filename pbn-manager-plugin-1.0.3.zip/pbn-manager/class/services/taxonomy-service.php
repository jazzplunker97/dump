<?php

class Taxonomy_Service
{
    /**
     * Get categories taxonomy
     *
     * @return array
     */
    public function get_categories(): array
    {
        $args = array(
            'hide_empty' => false,
        );
    
        $categories = get_categories($args);
        $categories_data = array();
    
        foreach ($categories as $tag) {
            $categories_data[] = array(
                'id' => $tag->term_id,
                'name' => $tag->name,
                'slug' => $tag->slug,
                'count' => $tag->count
            );
        }

        return $categories_data;
    }

    /**
     * Get tags taxonomy
     *
     * @return array
     */
    public function get_tags(): array
    {
        $args = array(
            'hide_empty' => false,
        );
    
        $tags = get_tags($args);
        $tags_data = array();
    
        foreach ($tags as $tag) {
            $tags_data[] = array(
                'id' => $tag->term_id,
                'name' => $tag->name,
                'slug' => $tag->slug,
                'count' => $tag->count
            );
        }

        return $tags_data;
    }
}