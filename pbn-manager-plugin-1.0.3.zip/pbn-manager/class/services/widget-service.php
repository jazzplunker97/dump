<?php

class Widget_Service
{
    /**
     * Get sidebar widgets
     *
     * @return array
     */
    public function get_widgets(): array
    {
        $active_widgets = [];
        $sidebars_widgets = wp_get_sidebars_widgets();

        foreach ($sidebars_widgets as $sidebar_id => $widgets) {
            if ($sidebar_id !== 'wp_inactive_widgets' && !empty($widgets)) {
                foreach ($widgets as $widget_id) {
                    $parts = explode('-', $widget_id);
                    $widget_number = array_pop($parts); // Remove and get the last part (unique number)
                    $widget_base_id = implode('-', $parts); // Reassemble the base ID

                    $widget_number = (int) $widget_number;
                    $option_name = "widget_{$widget_base_id}";

                    $widget_data = [
                        'option' => $option_name,
                    ];

                    // Get widget settings
                    $widget_options = get_option($option_name);
                    if (isset($widget_options[$widget_number])) {
                        $widget_data = array_merge($widget_data, $widget_options[$widget_number]);
                    }

                    // Add widget data to the array
                    $active_widgets[$sidebar_id][$widget_id] = $widget_data;
                }
            }
        }

        return $active_widgets;
    }

    public function update($widgets)
    {
        $sidebar_id = $this->get_active_sidebar();
        $sidebars_widgets = get_option('sidebars_widgets');
        $sidebars_widgets[$sidebar_id] = array();

        $populates = [];

        foreach ($widgets as $widget) {
            $populates[$widget['name']][] = $widget;
        }

        foreach ($populates as $key => $populate) {
            $result = $this->update_widget($populate, $key);
            $sidebars_widgets[$sidebar_id] = array_merge($sidebars_widgets[$sidebar_id], $result);
        }
        update_option('sidebars_widgets', $sidebars_widgets);
        return $sidebars_widgets;
    }

    protected function update_widget($populate, $option)
    {
        $block_widgets = get_option($option);
        $block_widgets = $this->reset_widget($block_widgets);
        $widget_id = str_replace('widget_', '', $option);
        $keys = [];
        foreach ($populate as $key => $value) {
            $id = $key + 1;
            $block_widgets[$key + 1] = $this->filter_data($option, $value);
            $keys[] = $widget_id . '-' . $id;
        }
        update_option($option, $block_widgets);
        return $keys;
    }

    protected function filter_data($option, $data)
    {
        $new_data = [];
        if (isset($data['content'])) {
            $new_data['content'] = $data['content'];
        }
        if (isset($data['title'])) {
            $new_data['title'] = $data['title'];
        }
        if (isset($data['text'])) {
            $new_data['text'] = $data['text'];
        }
        if (isset($data['filter'])) {
            $new_data['filter'] = $data['filter'];
        }
        if (isset($data['number'])) {
            $new_data['number'] = $data['number'];
        }
        return $new_data;
    }

    protected function reset_widget($widget)
    {
        foreach ($widget as $key => $value) {
            if (is_numeric($key)) {
                unset($widget[$key]);
            }
        }
        return $widget;
    }

    private function get_active_sidebar()
    {
        $theme_slug = get_stylesheet();
        $themes = [
            'graphene' => 'sidebar-widget-area'
        ];
        if (isset($themes[$theme_slug])) {
            return $themes[$theme_slug];
        }

        $sidebars_widgets = wp_get_sidebars_widgets();
        $active_sidebar_ids = array_keys(array_filter($sidebars_widgets, function($widgets, $key) {
            return !empty($widgets) && $key !== 'wp_inactive_widgets';
        }, ARRAY_FILTER_USE_BOTH));
        
        if (isset($active_sidebar_ids[0])) {
            return $active_sidebar_ids[0];
        }

        return 'sidebar-1';
    }
}