<?php

trait OptionTrait
{
    /**
     * Get options
     *
     * @return array
     */
    public function get_data(): array
    {
        $options = $this->get_unserialize();
        if ($site_icon = $options['site_icon']) {
            $options['site_icon'] = wp_get_attachment_image_url($site_icon, 'full');
        }
        return $options;
    }

    public function update_data($body)
    {
        $results = [];

        $options = $this->get_unserialize();

        foreach ($body as $key => $value) {
            switch ($key) {
                case 'wpseo':
                    $option = get_option('wpseo');
                    $option = $this->fill_updated($option, $body['wpseo']);
                    $results['wpseo'] = update_option('wpseo', $option);
                    break;
                case 'widget_block':
                    $option = get_option('widget_block');
                    $option = $this->fill_updated($option, $body['widget_block']);
                    $results['widget_block'] = update_option('widget_block', $option);
                    break;
                case 'sidebars_widgets':
                    $option = get_option('sidebars_widgets');
                    $option = $this->fill_updated($option, $body['sidebars_widgets']);
                    $results['sidebars_widgets'] = update_option('sidebars_widgets', $option);
                    break;
                case 'site_icon':
                    $imageUrl = $body['site_icon'];
                    $upload = wp_upload_bits(basename($imageUrl), null, file_get_contents($imageUrl));
                    if (!$upload['error']) {
                        $attachment = array(
                            'post_mime_type' => $upload['type'],
                            'post_title'     => sanitize_file_name(pathinfo($upload['file'], PATHINFO_FILENAME)),
                            'post_content'   => '',
                            'post_status'    => 'inherit',
                        );
                        $attachmentId = wp_insert_attachment($attachment, $upload['file']);
                        if (!is_wp_error($attachmentId)) {
                            $attachmentData = wp_generate_attachment_metadata($attachmentId, $upload['file']);
                            wp_update_attachment_metadata($attachmentId, $attachmentData);
                        }
                        $results['site_icon'] = update_option('site_icon', $attachmentId);
                    }
                    break;
                default:
                    $results[$key] = update_option($key, $value);
                    break;
            }
        }

        wp_cache_delete('alloptions', 'options');

        return $results;
    }

    protected function get_unserialize()
    {
        $options = wp_load_alloptions();
        foreach ($options as $name => $value) {
            $options[$name] = maybe_unserialize($value);
        }
        return $options;
    }

    protected function fill_updated($options, $updates)
    {
        foreach ($updates as $key => $value) {
            if (array_key_exists($key, $options)) {
                $options[$key] = $value;
            }
        }
        return $options;
    }
}