<?php

function render_dashboard_page() 
{
    ?>
    <div class="wrap">
        <h1>PBN DJ Manager</h1>

        <form method="post" action="" style="margin-top: 15px;">
            <?php
            if (isset($_POST['pbn_manager_token_submit'])) {
                update_option('pbn_manager_token', sanitize_text_field($_POST['pbn_manager_token']));
                echo '<div class="notice notice-success is-dismissible"><p>Options updated successfully!</p></div>';
            }
            ?>

            <table class="form-table">
                <tbody>
                    <tr>
                        <th scope="row">
                            <label for="pbn_manager_token">Token</label>
                        </th>
                        <td>
                            <input type="text" id="pbn_manager_token" class="regular-text" name="pbn_manager_token" value="<?php echo esc_attr(get_option('pbn_manager_token', '')); ?>" aria-describedby="token-description">
                            <p class="description" id="token-description">Make sure the token is same as in the PBN-M panel</p>
                        </td>
                    </tr>
                </tbody>
            </table>

            <p class="submit">
                <input type="submit" name="pbn_manager_token_submit" class="button button-primary" value="Save Changes">
            </p>
        </form>
    </div>
    <?php
}

function is_valid_token($token): bool
{
    return $token == get_option('pbn_manager_token', '');
}

function dump(...$data)
{
    echo '<pre>';
    echo print_r($data);
    echo '</pre>';
}

function dd(...$data)
{
    dump($data);
    die;
}