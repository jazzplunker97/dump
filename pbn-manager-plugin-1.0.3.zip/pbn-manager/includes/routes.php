<?php

require_once( __DIR__ . '/../class/routes/plugin-route.php' );
require_once( __DIR__ . '/../class/routes/theme-route.php' );
require_once( __DIR__ . '/../class/routes/post-route.php' );
require_once( __DIR__ . '/../class/routes/user-route.php' );
require_once( __DIR__ . '/../class/routes/option-route.php' );
require_once( __DIR__ . '/../class/routes/widget-route.php' );
require_once( __DIR__ . '/../class/routes/taxonomy-route.php' );