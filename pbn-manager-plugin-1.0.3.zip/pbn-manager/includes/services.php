<?php

require_once( __DIR__ . '/../class/services/plugin-service.php' );
require_once( __DIR__ . '/../class/services/widget-service.php' );
require_once( __DIR__ . '/../class/services/taxonomy-service.php' );