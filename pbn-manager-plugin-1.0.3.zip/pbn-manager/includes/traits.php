<?php

require_once( __DIR__ . '/../class/traits/option-trait.php' );