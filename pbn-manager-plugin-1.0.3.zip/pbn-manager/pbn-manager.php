<?php
/**
 * @package PBN_Manager
 * @version 1.0.3
 */
/*
Plugin Name: PBN DJ Manager
Plugin URI: https://github.com/djgroup88/pbn-manager-plugin
Description: Tools used to control multiple wordpress site.
Author: Jazz Plunker, DJ Group
Version: 1.0.3
Author URI: https://www.github.com/jazzplunker97
*/

// If this file is called directly, abort.
if ( !defined( 'ABSPATH' ) ) {
	die( 'We\'re sorry, but you can not directly access this file.' );
}

define('PBN_MANAGER_VERSION', '1.0.3');
define('PBN_MANAGER_INFO_URL', 'https://djpbnmanager.com/updater/info.json');

require_once( __DIR__ . '/includes/function.php' );
require_once( __DIR__ . '/class/option-class.php' );
require_once( __DIR__ . '/class/helper-class.php' );
require_once( __DIR__ . '/class/middleware-class.php' );
require_once( __DIR__ . '/includes/traits.php' );
require_once( __DIR__ . '/includes/routes.php' );
require_once( __DIR__ . '/includes/services.php' );
require_once( __DIR__ . '/class/api-route-class.php' );
require_once( __DIR__ . '/class/dashboard-class.php' );
require_once( ABSPATH . 'wp-admin/includes/image.php' );
require_once( ABSPATH . 'wp-admin/includes/taxonomy.php' );
require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
require_once( ABSPATH . 'wp-admin/includes/theme.php' );
require_once( ABSPATH . 'wp-admin/includes/plugin-install.php' );
require_once( ABSPATH . 'wp-admin/includes/class-wp-upgrader.php' );
require_once( ABSPATH . 'wp-admin/includes/class-wp-ajax-upgrader-skin.php' );
require_once( ABSPATH . 'wp-admin/includes/class-plugin-upgrader.php' );
require_once( ABSPATH . 'wp-admin/includes/file.php' );
require_once( ABSPATH . 'wp-admin/includes/user.php' );
require_once( ABSPATH . 'wp-includes/class-wp-widget.php' );

class PBNManager 
{
    public function initialize()
    {
        (new Route)->initialize();
        (new Dashboard)->initialize();
    }
}

$pbnManager = new PBNManager();
$pbnManager->initialize();

add_filter( 'plugins_api', 'pbn_manager_plugin_info', 20, 3);

function pbn_manager_plugin_info( $res, $action, $args ){
	if( 'plugin_information' !== $action ) {
		return $res;
	}

	if( plugin_basename( __DIR__ ) !== $args->slug ) {
		return $res;
	}

	$remote = wp_remote_get( PBN_MANAGER_INFO_URL,  array(
			'timeout' => 10,
			'headers' => array(
				'Accept' => 'application/json'
			) 
		)
	);

	if( is_wp_error( $remote ) || 200 !== wp_remote_retrieve_response_code( $remote ) || empty( wp_remote_retrieve_body( $remote ) )) {
		return $res;	
	}

	$remote = json_decode( wp_remote_retrieve_body( $remote ) );
	
	$res = new stdClass();
	$res->name = $remote->name;
	$res->slug = $remote->slug;
	$res->author = $remote->author;
	$res->author_profile = $remote->author_profile;
	$res->version = $remote->version;
	$res->tested = $remote->tested;
	$res->requires = $remote->requires;
	$res->requires_php = $remote->requires_php;
	$res->download_link = $remote->download_url;
	$res->trunk = $remote->download_url;
	$res->last_updated = $remote->last_updated;
	$res->sections = array(
		'description' => $remote->sections->description,
		'installation' => $remote->sections->installation,
		'changelog' => $remote->sections->changelog
	);
	if( ! empty( $remote->sections->screenshots ) ) {
		$res->sections[ 'screenshots' ] = $remote->sections->screenshots;
	}

	$res->banners = array(
		'low' => $remote->banners->low,
		'high' => $remote->banners->high
	);
	
	return $res;
}

add_filter( 'site_transient_update_plugins', 'pbn_manager_push_update' );
 
function pbn_manager_push_update( $transient ){
	if ( empty( $transient->checked ) ) {
		return $transient;
	}

	$remote = wp_remote_get( PBN_MANAGER_INFO_URL, array(
			'timeout' => 10,
			'headers' => array(
				'Accept' => 'application/json'
			)
		)
	);

	if( is_wp_error( $remote ) || 200 !== wp_remote_retrieve_response_code( $remote ) || empty( wp_remote_retrieve_body( $remote ) )) {
		return $transient;	
	}
	
	$remote = json_decode( wp_remote_retrieve_body( $remote ) );
 
	if(
		$remote
		&& version_compare( PBN_MANAGER_VERSION, $remote->version, '<' )
		&& version_compare( $remote->requires, get_bloginfo( 'version' ), '<' )
		&& version_compare( $remote->requires_php, PHP_VERSION, '<' )
	) {
		
		$res = new stdClass();
		$res->slug = $remote->slug;
		$res->plugin = plugin_basename( __FILE__ );
		$res->new_version = $remote->version;
		$res->tested = $remote->tested;
		$res->package = $remote->download_url;
		$transient->response[ $res->plugin ] = $res;
	}
 
	return $transient;
}